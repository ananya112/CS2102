public interface IContestant {


}

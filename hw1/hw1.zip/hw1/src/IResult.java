public interface IResult {

    public boolean isValid();
    public IResult getWinner();
}



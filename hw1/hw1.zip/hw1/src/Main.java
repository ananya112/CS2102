public class Main {
    public static void main(String[] args) {

    RugbyTeam america = new RugbyTeam("America", "Blue", false, 2, 3);
    RugbyTeam canada = new RugbyTeam("Canada", "Green", false, 3, 2);
    RoboticsTeam teamWPI = new RoboticsTeam("WPi", "powerful arm", 3);

    }
}

public interface IDailyWeather {
    public double getRain();
    public boolean isEqualMonth(int month);
    public double getTemp();
}

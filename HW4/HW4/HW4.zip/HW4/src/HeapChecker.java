public class HeapChecker {

   public HeapChecker() {}
    boolean addEltTester (IHeap hOrig,int elt, IBinTree hAdded){

        if (hAdded.hasElt(elt) && hAdded.isHeap() && hAdded.heepAdded(hOrig, hAdded) && hAdded.compare(hAdded, hOrig, elt)) {
            System.out.println(hAdded.hasElt(elt));
            System.out.println(hAdded.isHeap());
            System.out.println(hAdded.heepAdded(hOrig, hAdded));
            System.out.println(hAdded.compare(hAdded, hOrig, elt));
            return true;
        }
        return false;
    }

    boolean remMinEltTester (IHeap hOrig, IBinTree hRemoved){

        if (hRemoved.isHeap() && hRemoved.compare(hRemoved, hOrig, hRemoved.root()) && hRemoved.heepRemoved(hOrig, hRemoved)){
            System.out.println(hRemoved.isHeap());
            System.out.println(hRemoved.compare(hRemoved, hOrig, hRemoved.root()));
            System.out.println(hRemoved.heepRemoved(hOrig, hRemoved));
            return true;
        }

        return false;
    }

}






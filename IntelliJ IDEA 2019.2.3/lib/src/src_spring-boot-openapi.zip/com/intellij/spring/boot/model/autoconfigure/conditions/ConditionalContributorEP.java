// Copyright 2000-2019 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.model.autoconfigure.conditions;

import com.intellij.diagnostic.PluginException;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.extensions.CustomLoadingExtensionPointBean;
import com.intellij.openapi.util.NotNullLazyValue;
import com.intellij.util.KeyedLazyInstance;
import com.intellij.util.xmlb.annotations.Attribute;
import org.jetbrains.annotations.NotNull;

/**
 * Registers {@link ConditionalContributor} implementation via FQN of actual Condition.
 */
class ConditionalContributorEP extends CustomLoadingExtensionPointBean implements KeyedLazyInstance<ConditionalContributor> {
  /**
   * FQN of library condition class.
   */
  @Attribute("condition")
  public String condition;

  /**
   * IDE implementation of condition class.
   */
  @Attribute("implementation")
  public String implementation;

  private final NotNullLazyValue<ConditionalContributor> myHandler = NotNullLazyValue.createValue(() -> {
    try {
      return instantiateExtension(implementation, ApplicationManager.getApplication().getPicoContainer());
    }
    catch (Throwable e) {
      throw new PluginException("error instantiating " + implementation + " registered for condition " + condition, e, getPluginId());
    }
  });

  @NotNull
  @Override
  public ConditionalContributor getInstance() {
    return myHandler.getValue();
  }

  @Override
  public String getKey() {
    return condition;
  }
}

package com.intellij.sql.psi;

public interface SqlCaseExpression extends SqlCaseElement, SqlExpression {
}

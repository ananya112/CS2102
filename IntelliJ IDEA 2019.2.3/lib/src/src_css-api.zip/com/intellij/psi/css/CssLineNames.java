package com.intellij.psi.css;

public interface CssLineNames extends CssTerm {
}

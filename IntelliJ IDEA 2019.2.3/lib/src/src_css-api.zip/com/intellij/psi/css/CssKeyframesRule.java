package com.intellij.psi.css;

import com.intellij.psi.PsiNameIdentifierOwner;

public interface CssKeyframesRule extends CssAtRule, PsiNameIdentifierOwner, CssNamedElement {
}

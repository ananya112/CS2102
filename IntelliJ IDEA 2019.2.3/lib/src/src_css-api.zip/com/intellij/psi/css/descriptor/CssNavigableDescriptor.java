package com.intellij.psi.css.descriptor;

import com.intellij.psi.PsiElement;
import org.jetbrains.annotations.Nullable;

public interface CssNavigableDescriptor extends CssElementDescriptor {
  @Nullable
  PsiElement getElement();
}

package org.jetbrains.idea.tomcat;

import com.intellij.javaee.deployment.DeploymentSource;
import com.intellij.javaee.oss.server.JavaeeDeploymentModel;
import com.intellij.javaee.run.configuration.CommonModel;

public abstract class TomcatDeploymentModelBase extends JavaeeDeploymentModel {

  protected TomcatDeploymentModelBase(CommonModel parentConfiguration, DeploymentSource deploymentSource) {
    super(parentConfiguration, deploymentSource);
  }

  public abstract String getContextPath();
}

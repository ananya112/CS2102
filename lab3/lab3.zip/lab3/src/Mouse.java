public class Mouse {
    String foodType;
    int amtFood;
    

}
